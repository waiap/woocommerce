<?php
  include_once('admin/admin-paymentwall.php');
  include_once('admin/admin-fields.php');
  include_once('frontend/checkout-paymentwall.php');
?>
